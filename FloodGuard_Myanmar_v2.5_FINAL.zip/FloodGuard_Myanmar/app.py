import flask

app = flask.Flask(__name__)

# ── Flood & cholera risk data ─────────────────────────────────────────────────
# priorityScore: 0–100 scale (normalised from the 115-pt scoring engine)
# Thresholds: HIGH ≥ 77 | MEDIUM 54–76 | LOW < 54
FLOOD_DATA = {
    "Ayeyarwady": {
        "floodRisk": 9, "choleraRisk": 9,
        "vaccinePriority": "HIGH", "priorityScore": 95,
        "populationAffected": 820000, "lastFloodEvent": "2025-08",
        "description": "The Ayeyarwady Delta is Myanmar's most flood-prone region. Annual monsoon inundation displaces hundreds of thousands and creates acute cholera outbreak conditions. Flood probability modelled at 97% for 2026."
    },
    "Rakhine": {
        "floodRisk": 9, "choleraRisk": 8,
        "vaccinePriority": "HIGH", "priorityScore": 90,
        "populationAffected": 510000, "lastFloodEvent": "2025-08",
        "description": "Rakhine State faces cyclone-driven coastal surges and river flooding. Displaced populations in IDP camps have critically limited access to clean water and sanitation."
    },
    "Bago": {
        "floodRisk": 8, "choleraRisk": 7,
        "vaccinePriority": "HIGH", "priorityScore": 84,
        "populationAffected": 590000, "lastFloodEvent": "2025-09",
        "description": "Bago Region sees severe flooding along the Bago and Sittaung rivers each monsoon, with significant population displacement and high waterborne disease transmission risk."
    },
    "Mon": {
        "floodRisk": 8, "choleraRisk": 7,
        "vaccinePriority": "HIGH", "priorityScore": 82,
        "populationAffected": 380000, "lastFloodEvent": "2025-09",
        "description": "Mon State's coastal lowlands flood extensively during monsoon season, disrupting water supplies and elevating cholera risk across densely-populated river communities."
    },
    "Sagaing": {
        "floodRisk": 8, "choleraRisk": 6,
        "vaccinePriority": "HIGH", "priorityScore": 80,
        "populationAffected": 310000, "lastFloodEvent": "2025-08",
        "description": "Sagaing Region experiences severe Irrawaddy River flooding. Ongoing conflict has destroyed healthcare infrastructure, dramatically increasing cholera outbreak vulnerability."
    },
    "Kayin": {
        "floodRisk": 7, "choleraRisk": 6,
        "vaccinePriority": "HIGH", "priorityScore": 78,
        "populationAffected": 240000, "lastFloodEvent": "2025-09",
        "description": "Kayin State faces moderate-to-high flooding along the Salween and Gyaing rivers, with rural communities most exposed and limited healthcare access during flood events."
    },
    "Yangon": {
        "floodRisk": 7, "choleraRisk": 6,
        "vaccinePriority": "HIGH", "priorityScore": 77,
        "populationAffected": 1250000, "lastFloodEvent": "2025-09",
        "description": "Myanmar's largest city. Dense population and ageing drainage infrastructure make Yangon highly vulnerable to urban flash flooding and subsequent cholera exposure."
    },
    "Tanintharyi": {
        "floodRisk": 7, "choleraRisk": 5,
        "vaccinePriority": "MEDIUM", "priorityScore": 68,
        "populationAffected": 190000, "lastFloodEvent": "2025-09",
        "description": "Tanintharyi's long coastline and river systems flood heavily during monsoon season. Coastal communities face significant annual disruption to water and sanitation services."
    },
    "Mandalay": {
        "floodRisk": 6, "choleraRisk": 5,
        "vaccinePriority": "MEDIUM", "priorityScore": 62,
        "populationAffected": 340000, "lastFloodEvent": "2025-08",
        "description": "Mandalay faces moderate Irrawaddy River flooding. Urban water supply disruption during flood events elevates cholera risk in densely populated central districts."
    },
    "Kachin": {
        "floodRisk": 5, "choleraRisk": 4,
        "vaccinePriority": "MEDIUM", "priorityScore": 58,
        "populationAffected": 148000, "lastFloodEvent": "2025-07",
        "description": "Kachin State's mountainous terrain produces flash floods in river valleys. Internally displaced persons face the highest health exposure risk during flood season."
    },
    "Magway": {
        "floodRisk": 5, "choleraRisk": 4,
        "vaccinePriority": "MEDIUM", "priorityScore": 55,
        "populationAffected": 210000, "lastFloodEvent": "2025-08",
        "description": "Magway's dry zone sees less severe flooding overall, but low-lying rural settlements remain exposed to flash floods and lack adequate sanitation infrastructure."
    },
    "Shan": {
        "floodRisk": 4, "choleraRisk": 3,
        "vaccinePriority": "LOW", "priorityScore": 45,
        "populationAffected": 130000, "lastFloodEvent": "2025-07",
        "description": "Shan State's high plateau limits widespread flooding. River valleys and lower-lying townships experience seasonal flash floods, primarily affecting agricultural communities."
    },
    "Chin": {
        "floodRisk": 3, "choleraRisk": 2,
        "vaccinePriority": "LOW", "priorityScore": 30,
        "populationAffected": 58000, "lastFloodEvent": "2024-08",
        "description": "Chin State's mountainous geography produces landslide risk over flood risk. Cholera incidence remains among the lowest nationally."
    },
    "Kayah": {
        "floodRisk": 3, "choleraRisk": 2,
        "vaccinePriority": "LOW", "priorityScore": 28,
        "populationAffected": 52000, "lastFloodEvent": "2024-08",
        "description": "Kayah State has the lowest flood risk nationally due to elevated terrain. Localised flooding occurs in some townships but overall cholera exposure is minimal."
    },
    "Nay Pyi Taw": {
        "floodRisk": 3, "choleraRisk": 3,
        "vaccinePriority": "LOW", "priorityScore": 32,
        "populationAffected": 75000, "lastFloodEvent": "2024-09",
        "description": "The capital union territory has better infrastructure than most regions. Some rural townships remain vulnerable during heavy monsoon rains but risk is comparatively low."
    }
}

@app.route('/')
def index():
    return flask.render_template('index.html')

@app.route('/map')
def map_page():
    return flask.render_template('map.html')

@app.route('/api/flood-data')
def flood_data():
    return flask.jsonify(FLOOD_DATA)

if __name__ == '__main__':
    app.run(debug=True)
